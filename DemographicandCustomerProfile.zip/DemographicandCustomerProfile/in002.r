# plot call time with density 
setwd('/bigdata/projects/Pelican')

library(data.table)
library(ggplot2)

str <- '
19	No Contact - Answering Machine
112	Contact - Promise To Pay
21	No Contact - Answering Machine
4	No Contact - Answering Machine
8	No Contact - Answering Machine
6	Contact - Promise To Pay
6	No Contact - Answering Machine
34	Contact - Promise To Pay
19	No Contact - Answering Machine
'

dat <- fread(str)

dat <- fread('/bigdata/projects/Pelican/Density.dat', sep = '\001')
# summary(dat)

setnames(dat, 'V1', 'call_duaration')
setnames(dat, 'V2', 'type')




dat_short_calls <- dat[call_duaration < 100]
table(dat$call_duaration > 100)/nrow(dat)
# FALSE       TRUE
# 0.94913885 0.05086115
pdf('IN002_less_than_100_sec.pdf')
ggplot(dat_short_calls, aes(call_duaration, colour=type)) + geom_density()
dev.off()



dat_long_calls <- dat[call_duaration > 100 & call_duaration < 1000]
table(dat$call_duaration > 100 & dat$call_duaration < 1000)/nrow(dat)
# FALSE       TRUE
# 0.95284077 0.04715923
pdf('IN002_call_len_100_to_10000_sec.pdf')
ggplot(dat_long_calls, aes(call_duaration, colour=type)) + geom_density()
dev.off()



