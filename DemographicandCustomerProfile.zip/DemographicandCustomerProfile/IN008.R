library(data.table)
data=fread("/bigdata/projects/Pelican/TempSidd1.csv",colClasses='character',sep='\001')

TempSidd1.csv

setnames(data,c("accountnumber","rpc_rate","hour","num_of_dials"))
data1$rpc_rate=round(as.numeric(data$rpc_rate),2)
library(reshape2)
data2=dcast.data.table(data1,accountnumber ~ hour,value.var="rpc_rate")
data3=unique(data[,c("accountnumber","num_of_dials"),with=F])
final=merge(data2,data3,by="accountnumber",all.x=T)
final[is.na(final)] <- 0

final16=final[,-c(1,18),with=F]
apply(final16,2,as.numeric)
km=kmeans(final16,centers=10)
summary(km)

 table(km$centers)
names(km)
table(km$cluster)
 
ff1=data.frame()
for(i in 1:10)
{
ff=final[which(km$cluster==i),]
ff=data.frame(ff,"cluster_no"=rep(paste("cluster_",i,sep=""),nrow(ff)))
ff1=rbind(ff1,ff)
}


dim(ff)
 head(ff)
ff2=ff1
setorder(ff2, -num_of_dials)
write.csv(ff2,"/bigdata/projects/Pelican/Temp_Final.csv",row.names=F)

---num of dials > 100---------------------------------

 final15=final[num_of_dials >100,]
final15=final[as.numeric(final$num_of_dials) >100,]

apply(final15,2,as.numeric)
 head(final15)
 
  
  final16=final15[,-c(1,18),with=F]
apply(final[,-c(1,18),with=F],2,as.numeric)

final[,-c(1,18),with=F]

 km=kmeans(final,centers=10)

km=kmeans(final[,-c(1,18),with=F],centers=10)
final[,-c(1,18),with=F]


 
ff1=data.frame()
 table(km$cluster)
 for(i in 1:10)
{
ff=final15[which(km$cluster==i),]
ff=data.frame(ff,"cluster_no"=rep(paste("cluster_",i,sep=""),nrow(ff)))
ff1=rbind(ff1,ff)
}
write.csv(ff1,"/bigdata/projects/Pelican/TempRPC_NumofCallsGt100_Normalised.csv",row.names=F)


setnames(data,c("accountnumber","right_party","hour","num_of_dials","bl_rpc"))

-------------------------------------------------------- code for Normalised RPC---------------------------

mydata=fread("/bigdata/projects/Pelican/TempSidd1.csv",colClasses='character',sep='\001')
setnames(mydata,c("accountnumber","right_party","hour","num_of_dials","bl_rpc"))
library(reshape2)
data2=dcast.data.table(mydata,accountnumber ~ hour,value.var="bl_rpc")
data3=unique(data[,c("accountnumber","num_of_dials"),with=F])
final=merge(data2,data3,by="accountnumber",all.x=T)

final[is.na(final)] <- 0
final16=apply(final16,2,as.numeric)
final16=as.data.frame(final16)
km=kmeans(final16,centers=10)
table(km$centers)
names(km)
table(km$cluster)
 
ff1=data.frame()
for(i in 1:10)
{
ff=final[which(km$cluster==i),]
ff=data.frame(ff,"cluster_no"=rep(paste("cluster_",i,sep=""),nrow(ff)))
ff1=rbind(ff1,ff)
}
 ff2$num_of_dials=as.numeric(ff2$num_of_dials)


dim(ff)

 head(ff)
ff2=ff1
setorder(ff2, -num_of_dials)
write.csv(ff2,"/bigdata/projects/Pelican/TempRPC_NormalisedUpdated.csv",row.names=F)



 final15=final[num_of_dials >100,]
 



--------------------------------------------------------------------------------------------------------

 aggregate(mydata1[,-17,with=F],mydata1$cluster_no,mean)
  
 aggregate(my1[,-17,with=F],my1$cluster_no,mean)

 aggregate(mydata[,-c(1:18),with=F],list(mydata1$cluster_no),mean)





sapply(my1[,-17,with=F],as.numeric)

 mydata1 <- mydata[,-c(1:17),with=F]


 my1 <- mydata[,-c(1,18),with=F]
 my1 <- mydata[,-17,with=F]

 my1 <- ff2[,-c(1,18),with=F]


ff2[,-17]

 my2 <- aggregate(my1[,-17,with=F],list(my1$cluster_no),mean)


my3 <- aggregate(my1[,-17],list(my1$cluster_no),mean)





my1 <- sapply(my1[,-17,with=F],as.numeric)



 temp <- colnames(my1[,-17,with=F])

my1[,temp] <- lapply(my1[,temp,na.rm=TRUE],as.numeric)





-------------------------------------------
my1 <- ff2[,-17]
 my1 <- ff2[,-c(1,18)]


temp <- colnames(my1[,-17])
my1[,temp] <- lapply(my1[,temp],as.numeric)

my3 <- aggregate(my1[,-17],list(my1$cluster_no),mean)

write.csv(my3,"/bigdata/projects/Pelican/TempRPC_MeanUpdated1.csv",row.names=F)


frequency find out through 
data.frame(table(ff2$cluster_no))

         Var1   Freq
1   cluster_1   2857
2   cluster_2   3717
3   cluster_3 945082
4   cluster_4   4769
5   cluster_5   5618
6   cluster_6   4023
7   cluster_7   7154
8   cluster_8   4558
9   cluster_9   5265
10 cluster_10   4862







